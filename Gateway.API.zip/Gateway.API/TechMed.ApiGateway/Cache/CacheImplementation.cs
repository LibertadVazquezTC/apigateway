﻿using Microsoft.Extensions.Caching.Memory;
using Ocelot.Cache;
using System;

namespace TechMed.ApiGateway.Cache
{
    public class CacheImplementation : IOcelotCache<CachedResponse>
    {

        private IMemoryCache _cache;

        public CacheImplementation(IMemoryCache memoryCache)
        {
            _cache = memoryCache;
        }

        public void Add(string key, CachedResponse value, TimeSpan ttl, string region)
        {
            if (value.StatusCode == System.Net.HttpStatusCode.OK)
                _cache.Set(key, value, ttl);
        }

        public void AddAndDelete(string key, CachedResponse value, TimeSpan ttl, string region)
        {
            //No se usa...
        }

        public void ClearRegion(string region)
        {
            //No se usa...
        }

        public CachedResponse Get(string key, string region)
        {
            return _cache.Get<CachedResponse>(key);
        }
    }
}
