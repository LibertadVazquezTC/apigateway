﻿using Microsoft.Extensions.DependencyInjection;

namespace TechMed.ApiGateway.Extensions
{
    public static class CorsExtension
    {
        public static void ConfigureCors(this IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                  builder =>
                  {
                      builder.WithOrigins(
                          "https://techmed.acudir.net",
                          "http://localhost:8080",
                          "http://localhost:8081")
                      .SetIsOriginAllowedToAllowWildcardSubdomains()
                      .AllowAnyHeader()
                      .AllowAnyMethod()
                      .AllowCredentials();
                  });
            });
        }
    }
}
