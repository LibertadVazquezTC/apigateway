﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System;
using System.Text;
using TechMed.ApiGateway.Repositories.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace TechMed.ApiGateway.Extensions
{
    public static class AuthenticationExtension
    {
        public static void ConfigureAuthentication(this IServiceCollection services)
        {
            string secretKey = "XCAP05H6LoKvbRRa/QkqLNMI7cOHguaRyHzyg7n5qEkGjQmtBhz4SzYh4Fqwjyi3KJHlSXKPwVu2+bXr6CtpgQ==";

            services
                .AddAuthentication()
                .AddJwtBearer("Bearer", options =>
                {
                    options.RequireHttpsMetadata = false;
                    options.SaveToken = true;
                    options.TokenValidationParameters = new TokenValidationParameters()
                    {
                        ValidIssuers = null,
                        ValidAudience = null,
                        ValidateIssuer = false,
                        ValidateAudience = false,
                        RequireExpirationTime = false,
                        ValidateLifetime = false,
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.Default.GetBytes(secretKey)),
                        ClockSkew = TimeSpan.Zero
                    };

                    options.Events = new JwtBearerEvents
                    {
                        OnTokenValidated = async ctx =>
                        {
                            bool tieneUsuarioId = ctx.Principal.HasClaim(c => c.Type == "u_id");
                            if (!tieneUsuarioId)
                                ctx.Fail("No se encontro el id de usuario en el claim.");

                            int usuarioId = int.Parse(ctx.Principal.FindFirst("u_id").Value);
                            if (usuarioId == 0)
                                ctx.Fail("El id de usuario no puede ser 0.");

                            var _usuarioRepository = ctx.HttpContext.RequestServices.GetRequiredService<IUsuarioRepository>();
                            await _usuarioRepository.Autenticar(usuarioId);

                        },
                        OnAuthenticationFailed = async ctx =>
                        {
                            string mensajeError = ctx.Exception != null && ctx.Exception.Message != null ?
                                ctx.Exception.Message : "Fallo autenticacion.";

                            JObject jObject = new JObject
                            {
                                ["message"] = mensajeError
                            };

                            ctx.Response.StatusCode = (int)StatusCodes.Status401Unauthorized;
                            ctx.Response.ContentType = "application/json";
                            await ctx.Response.WriteAsync(jObject.ToString());
                        }
                    };
                });
        }
    }
}
