﻿using Microsoft.Extensions.DependencyInjection;
using TechMed.ApiGateway.Repositories;
using TechMed.ApiGateway.Repositories.Interfaces;

namespace TechMed.ApiGateway.Extensions
{
    public static class RepositoryExtension
    {
        public static void ConfigureRepositories(this IServiceCollection services)
        {
            services.AddScoped<IUsuarioRepository, UsuarioRepository>();
        }
    }
}
