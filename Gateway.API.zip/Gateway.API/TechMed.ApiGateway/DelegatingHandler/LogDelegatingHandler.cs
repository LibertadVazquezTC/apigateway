﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using TechMed.ApiGateway.DTOs;
using System;
using System.Text;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Net;
using System.Collections.Generic;
using System.Security.Claims;
using System.Linq;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.Extensions.Configuration;

namespace TechMed.ApiGateway.Delegating
{
    public class LogDelegatingHandler : DelegatingHandler
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public LogDelegatingHandler(IConfiguration configuration,
            IHttpContextAccessor httpContextAccessor,
            IHttpClientFactory clientFactory)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
            _clientFactory = clientFactory;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage httpRequestMessage, CancellationToken cancellationToken)
        {
            WebApiLogDTO webApiLog = new WebApiLogDTO();
            string method = httpRequestMessage.Method.Method;

            if (method != "GET")
            {
                webApiLog.WebApiId = 1;
                webApiLog.Ip = _httpContextAccessor.HttpContext.Connection.RemoteIpAddress.ToString();
                webApiLog.Url = httpRequestMessage.RequestUri.AbsoluteUri;
                webApiLog.RequestType = httpRequestMessage.Method.Method;
                webApiLog.ContentType = httpRequestMessage.Content.Headers.ContentType == null ? "" : httpRequestMessage.Content.Headers.ContentType.ToString();
                webApiLog.Content = httpRequestMessage.Content.ReadAsStringAsync().Result;
                webApiLog.Usuario = UserName();
                webApiLog.Fecha = DateTime.Now;
                webApiLog.WebApiLogId = await GenerarLog(webApiLog);
            }

            HttpResponseMessage httpResponseMessage = await base.SendAsync(httpRequestMessage, cancellationToken);

            if (method != "GET" && webApiLog.WebApiLogId > 0)
            {
                if (httpResponseMessage.Content is null)
                    webApiLog.Response = "";
                else
                    webApiLog.Response = httpResponseMessage.Content.ReadAsStringAsync().Result;

                webApiLog.ResponseStatusCode = (int)httpResponseMessage.StatusCode;
                webApiLog.ResponseStatusMessage = httpResponseMessage.StatusCode.ToString();
                webApiLog.ResponseFecha = DateTime.Now;
                await ActualizarLog(webApiLog);
            }

            return httpResponseMessage;
        }

        private async Task<int> GenerarLog(WebApiLogDTO webApiLog)
        {
            int webApiLogId = 0;
            try
            {
                string segLogueoUrl = _configuration.GetSection("SegLogueo").Value;

                HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, $"{segLogueoUrl}/api/ApiLog");
                httpRequestMessage.Headers.Add("Accept", "application/json");
                httpRequestMessage.Content = new StringContent(JsonConvert.SerializeObject(webApiLog), Encoding.UTF8, "application/json");
                HttpClient httpClient = _clientFactory.CreateClient();
                HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(httpRequestMessage);

                if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
                    webApiLogId = JsonConvert.DeserializeObject<int>(httpResponseMessage.Content.ReadAsStringAsync().Result);

                return webApiLogId;
            }
            catch (Exception)
            {
                return webApiLogId;
            }
        }

        private async Task ActualizarLog(WebApiLogDTO webApiLog)
        {
            try
            {
                string segLogueoUrl = _configuration.GetSection("SegLogueo").Value;

                HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Put, $"{segLogueoUrl}/api/ApiLog");
                httpRequestMessage.Headers.Add("Accept", "application/json");
                httpRequestMessage.Content = new StringContent(JsonConvert.SerializeObject(webApiLog), Encoding.UTF8, "application/json");
                HttpClient httpClient = _clientFactory.CreateClient();
                HttpResponseMessage httpResponseMessage = await httpClient.SendAsync(httpRequestMessage);
            }
            catch (Exception)
            {
                return;
            }
        }

        public string UserName()
        {
            string userName = _httpContextAccessor.HttpContext?.User?.Identity?.Name;
            return string.IsNullOrEmpty(userName) ? "N/A" : userName;
        }
    }
}
