﻿using System;
using System.Text;
using System.Data;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Net;
using System.Linq;
using TechMed.ApiGateway.Exceptions;
using Microsoft.Extensions.Configuration;
using Dapper;

namespace TechMed.ApiGateway.Delegating
{
    public class AuthorizationDelegatingHandler : DelegatingHandler
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuthorizationDelegatingHandler(IConfiguration configuration,
            IHttpContextAccessor httpContextAccessor)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
        }

        public IDbConnection Connection => new SqlConnection(_configuration.GetConnectionString("AuthDatabase"));

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage httpRequestMessage, CancellationToken cancellationToken)
        {
            string method = string.Empty;
            string path = string.Empty;

            try
            {
                int usuarioId = UsuarioId();
                bool tienePermisos = false;

                method = _httpContextAccessor.HttpContext.Request.Method;
                path = _httpContextAccessor.HttpContext.Request.Path.Value;

                using (IDbConnection connection = Connection)
                {
                    var tienePermisosResponse = (await connection.QueryAsync<bool>($"SELECT dbo.fn_SegAuth({usuarioId}, '{method}', '{path}')")).ToList();
                    tienePermisos = tienePermisosResponse[0];
                }

                if (!tienePermisos)
                    throw new SinPermisosException("No tiene permisos para realizar la acción indicada.");

                return await base.SendAsync(httpRequestMessage, cancellationToken);
            }
            catch (Exception ex)
            {
                if (ex is SinPermisosException)
                {
                    return new HttpResponseMessage(HttpStatusCode.Forbidden)
                    {
                        Content = new StringContent(JsonConvert.SerializeObject(new { message = ex.Message, error_path = path, error_method = method }), Encoding.UTF8, "application/json"),
                        ReasonPhrase = "Fallo autorizacion."
                    };
                }
                else
                {
                    return new HttpResponseMessage(HttpStatusCode.BadRequest)
                    {
                        Content = new StringContent(JsonConvert.SerializeObject(new { message = ex.Message }), Encoding.UTF8, "application/json"),
                        ReasonPhrase = "Fallo inesperado"
                    };
                }
            }
        }

        public int UsuarioId()
        {
            bool tieneUsuarioId = _httpContextAccessor.HttpContext.User.HasClaim(c => c.Type == "u_id");
            if (!tieneUsuarioId)
                throw new TokenFaltanteException("Código E0911-NH. Vuelva a ingresar al sistema.");

            int usuarioId = int.Parse(_httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "u_id").Value);
            if (usuarioId == 0)
                throw new TokenFaltanteException("Código E0911-NH. Vuelva a ingresar al sistema.");

            return usuarioId;
        }
    }
}
