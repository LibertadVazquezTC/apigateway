﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace TechMed.ApiGateway.Modelo
{
    public partial class AuthContext : DbContext
    {
        public AuthContext()
        {
        }

        public AuthContext(DbContextOptions<AuthContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Usuario> Usuario { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=192.168.1.12;Database=TechMed_Auth_test;User ID=tmuser;Password=pepito_123;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Usuario>(entity =>
            {
                entity.Property(e => e.AuditoriaInsertDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaInsertUser).HasMaxLength(128);

                entity.Property(e => e.AuditoriaUpdateDate).HasColumnType("datetime");

                entity.Property(e => e.AuditoriaUpdateUser).HasMaxLength(128);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Nombre)
                    .IsRequired()
                    .HasMaxLength(128);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(256);

                entity.Property(e => e.Token).HasMaxLength(512);

                entity.Property(e => e.TokenFechaExpiracion).HasColumnType("datetime");

                entity.Property(e => e.TokenIp).HasMaxLength(50);

                entity.Property(e => e.TokenUltimaActualizacion).HasColumnType("datetime");

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50);
            });
        }
    }
}
