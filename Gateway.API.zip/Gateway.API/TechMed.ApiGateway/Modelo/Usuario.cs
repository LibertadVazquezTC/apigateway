﻿using System;
using System.Collections.Generic;

namespace TechMed.ApiGateway.Modelo
{
    public partial class Usuario
    {
        public int UsuarioId { get; set; }
        public int? ProveedorId { get; set; }
        public int? ClienteId { get; set; }
        public string Nombre { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public int IntentosFallidosIngreso { get; set; }
        public string Token { get; set; }
        public string TokenIp { get; set; }
        public DateTime? TokenFechaExpiracion { get; set; }
        public DateTime? TokenUltimaActualizacion { get; set; }
        public int? TokenTiempoExpiracion { get; set; }
        public bool Bloqueado { get; set; }
        public bool Activo { get; set; }
        public string AuditoriaInsertUser { get; set; }
        public DateTime AuditoriaInsertDate { get; set; }
        public string AuditoriaUpdateUser { get; set; }
        public DateTime? AuditoriaUpdateDate { get; set; }
    }
}
