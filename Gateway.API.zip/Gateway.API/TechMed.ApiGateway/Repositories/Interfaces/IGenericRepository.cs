﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace TechMed.ApiGateway.Repositories.Interfaces
{
    public interface IGenericRepository<TEntity> where TEntity : class
    {
        #region Métodos asincrónicos
        Task<TEntity> GetByIdAsync(int id);

        Task<IEnumerable<TEntity>> GetAllAsync();

        Task<IEnumerable<TEntity>> GetManyAsync(Expression<Func<TEntity, bool>> predicate);

        Task AddAsync(TEntity entity);

        Task AddRangeAsync(TEntity entity);

        Task SaveChangesAsync();
        #endregion

        #region Métodos sincrónicos
        TEntity GetById(int id);

        IEnumerable<TEntity> GetAll();

        IEnumerable<TEntity> GetMany(Expression<Func<TEntity, bool>> predicate);

        TEntity GetByCondition(Expression<Func<TEntity, bool>> predicate);

        void Add(TEntity entity);

        void AddRange(TEntity entity);

        void Update(TEntity entity);

        void UpdateRange(TEntity entity);

        void SaveChanges();
        #endregion
    }
}
