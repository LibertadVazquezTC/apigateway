﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TechMed.ApiGateway.Modelo;

namespace TechMed.ApiGateway.Repositories.Interfaces
{
    public interface IUsuarioRepository
    {
        Task Autenticar(int usuarioId);
    }
}
