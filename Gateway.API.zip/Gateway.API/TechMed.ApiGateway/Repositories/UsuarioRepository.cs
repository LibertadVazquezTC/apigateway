﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;
using TechMed.ApiGateway.Exceptions;
using TechMed.ApiGateway.Modelo;
using TechMed.ApiGateway.Repositories.Interfaces;

namespace TechMed.ApiGateway.Repositories
{
    public class UsuarioRepository : GenericRepository<Usuario>, IUsuarioRepository
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UsuarioRepository(AuthContext dbContext,
            IHttpContextAccessor httpContextAccessor)
           : base(dbContext)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        //E0911-NH El header de autorización no está presente.
        //E2602-TMF Token mal formado.
        //E1603-TE Token expirado.
        //E1509-TV Token vencido.
        //E1905-TD Token distinto al guardado.
        public async Task Autenticar(int usuarioId)
        {
            StringValues authorizationHeaders;
            if (!_httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Authorization", out authorizationHeaders) || authorizationHeaders.Count != 1)
                throw new TokenFaltanteException("E0911-NH. Vuelva a ingresar al sistema.");

            string bearerToken = authorizationHeaders.ElementAt(0);

            if (string.IsNullOrEmpty(bearerToken) || !bearerToken.StartsWith("Bearer "))
                throw new TokenFaltanteException("Código E2602-TMF. Vuelva a ingresar al sistema.");

            string jwtToken = bearerToken.Substring(7);

            Usuario usuario = await Obtener(usuarioId);

            //1) Valido que el token no haya sido modificado
            if (!usuario.Token.Equals(jwtToken))
                throw new TokenDistintoException("Código E1905-TD. Vuelva a ingresar al sistema.");

            //2) Valido que no haya expirado
            if (usuario.TokenFechaExpiracion != null)
                throw new TokenExpiradoException("Código E1603-TE. Vuelva a ingresar al sistema.");

            //3) Valido que no haya vencido
            if (!usuario.TokenUltimaActualizacion.HasValue)
                throw new TokenVencidoException("Código E1509-TV. Vuelva a ingresar al sistema.");

            //4) Valido que tenga expiración
            if (!usuario.TokenTiempoExpiracion.HasValue)
                throw new TokenVencidoException("Código E1509-TV. Vuelva a ingresar al sistema.");

            JwtSecurityTokenHandler jwtSecurityTokenHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken jwtSecurityToken = jwtSecurityTokenHandler.ReadJwtToken(usuario.Token);

            string issuedAtEnFormatoUnix = jwtSecurityToken.Claims.First(x => x.Type == "iat").Value;
            DateTime issuedAt = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            issuedAt = issuedAt.AddSeconds(int.Parse(issuedAtEnFormatoUnix)).ToLocalTime();

            if (DateTime.Now > usuario.TokenUltimaActualizacion.Value.AddMinutes(usuario.TokenTiempoExpiracion.Value))
                throw new TokenVencidoException("Código E1509-TV. Vuelva a ingresar al sistema.");

            await Actualizar(usuario);
        }

        private async Task<Usuario> Obtener(int usuarioId)
        {
            return await GetByIdAsync(usuarioId);
        }

        private async Task Actualizar(Usuario usuario)
        {
            usuario.TokenUltimaActualizacion = DateTime.Now;
            usuario.AuditoriaUpdateDate = DateTime.Now;
            usuario.AuditoriaUpdateUser = usuario.Username;

            Update(usuario);
            await SaveChangesAsync();
        }
    }
}
