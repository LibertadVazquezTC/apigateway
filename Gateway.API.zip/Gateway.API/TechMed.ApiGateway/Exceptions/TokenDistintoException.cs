﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenDistintoException : Exception
    {
        public TokenDistintoException(string mensaje) : base(mensaje)
        {

        }
    }
}
