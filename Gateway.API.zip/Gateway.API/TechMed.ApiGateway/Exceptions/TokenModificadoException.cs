﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenModificadoException : Exception
    {
        public TokenModificadoException(string mensaje) : base(mensaje)
        {

        }
    }
}
