﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenIpDiferenteException : Exception
    {
        public TokenIpDiferenteException(string mensaje) : base(mensaje)
        {

        }
    }
}
