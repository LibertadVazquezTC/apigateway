﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenInvalidoException : Exception
    {
        public TokenInvalidoException(string mensaje) : base(mensaje)
        {

        }
    }
}
