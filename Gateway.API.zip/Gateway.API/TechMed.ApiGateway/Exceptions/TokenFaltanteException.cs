﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenFaltanteException : Exception
    {
        public TokenFaltanteException(string mensaje) : base(mensaje)
        {

        }
    }
}
