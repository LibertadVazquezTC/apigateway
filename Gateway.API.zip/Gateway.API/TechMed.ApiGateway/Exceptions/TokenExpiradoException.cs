﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenExpiradoException : Exception
    {
        public TokenExpiradoException(string mensaje) : base(mensaje)
        {

        }
    }
}
