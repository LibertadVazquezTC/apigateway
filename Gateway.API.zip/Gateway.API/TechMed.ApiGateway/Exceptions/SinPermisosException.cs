﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class SinPermisosException : Exception
    {
        public SinPermisosException(string mensaje) : base(mensaje)
        {
            
        }
    }
}
