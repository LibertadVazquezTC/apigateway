﻿using System;

namespace TechMed.ApiGateway.Exceptions
{
    public class TokenVencidoException : Exception
    {
        public TokenVencidoException(string mensaje) : base(mensaje)
        {

        }
    }
}
